
import React, { useState, useRef, useEffect } from 'react';
import { analyzeEnvironmentalImage } from '../services/geminiService';
import { AIAnalysisResult, IncidentType, Severity, Report } from '../types';

interface ReportWizardProps {
  onComplete: (report: Partial<Report>) => void;
}

const ReportWizard: React.FC<ReportWizardProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [description, setDescription] = useState('');
  const [manualAddress, setManualAddress] = useState('');
  const [location, setLocation] = useState<{lat: number, lng: number, address: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const initialAddr = "Fetching address from coordinates...";
        setLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          address: initialAddr
        });
        setManualAddress(initialAddr);
        
        // Simulated reverse geocoding
        setTimeout(() => {
          const detected = `Sector ${Math.floor(Math.random()*100)}, Green Zone Highway`;
          setLocation(prev => prev ? ({...prev, address: detected}) : null);
          setManualAddress(detected);
        }, 1500);
      }, (err) => {
        setManualAddress("Manual input required - GPS unavailable");
      });
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setStep(2);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStartAnalysis = async () => {
    if (!image) return;
    setAnalyzing(true);
    try {
      const base64Data = image.split(',')[1];
      const result = await analyzeEnvironmentalImage(base64Data);
      setAnalysis(result);
      setStep(3);
    } catch (err) {
      alert("AI analysis failed. Please enter details manually.");
      setStep(3);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSubmit = () => {
    onComplete({
      type: analysis?.detectedType || IncidentType.OTHER,
      severity: analysis?.severity || Severity.MEDIUM,
      description: description || analysis?.explanation || '',
      imageUrl: image || undefined,
      aiInsights: analysis?.explanation,
      location: { 
        lat: location?.lat || 0, 
        lng: location?.lng || 0, 
        address: manualAddress || location?.address || "Manual Input Location" 
      },
      timestamp: new Date(),
    });
  };

  return (
    <div className="bg-white rounded-[3rem] p-10 shadow-2xl max-w-xl mx-auto border border-emerald-100 animate-slide-up">
      <div className="flex items-center gap-4 mb-10">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
            <div className={`h-full transition-all duration-700 ${step >= s ? 'bg-emerald-500' : 'bg-transparent'}`} />
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="text-center py-10">
          <div className="w-24 h-24 bg-emerald-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-emerald-600 shadow-inner">
            <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" strokeWidth="2"/><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" strokeWidth="2"/></svg>
          </div>
          <h2 className="text-3xl font-black mb-4 tracking-tight">Capture Evidence</h2>
          <p className="text-slate-500 mb-10 font-medium">Your data helps authorities react faster. Upload a high-resolution image of the incident.</p>
          <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />
          <button onClick={() => fileInputRef.current?.click()} className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-black transition-all">Select Media File</button>
        </div>
      )}

      {step === 2 && image && (
        <div className="text-center">
          <div className="relative group mb-8">
            <img src={image} className="w-full aspect-square object-cover rounded-[2.5rem] shadow-2xl" alt="Evidence" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-[2.5rem] flex items-center justify-center">
              <button onClick={() => setImage(null)} className="p-4 bg-white/20 backdrop-blur-md rounded-full text-white">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2"/></svg>
              </button>
            </div>
          </div>
          <h2 className="text-2xl font-black mb-2">AI Analysis Engine</h2>
          <p className="text-slate-500 mb-8 font-medium">Use computer vision to automatically detect severity and incident type.</p>
          <div className="flex gap-4">
            <button disabled={analyzing} onClick={handleStartAnalysis} className="flex-1 bg-indigo-600 text-white font-black py-4 rounded-2xl shadow-lg hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center justify-center gap-3">
              {analyzing ? "Synthesizing..." : "Deep Scan Image"}
            </button>
            <button disabled={analyzing} onClick={() => setStep(3)} className="px-8 border border-slate-200 font-black py-4 rounded-2xl text-slate-400">Skip</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-8 animate-in fade-in duration-500">
          {/* Editable Incident Address Section */}
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Incident Site Address</p>
               </div>
               {manualAddress && manualAddress !== "Fetching address from coordinates..." && (
                 <span className="text-[8px] font-black bg-emerald-100 text-emerald-700 px-2 py-1 rounded-md">VERIFIED GPS</span>
               )}
            </div>
            <div className="relative">
              <input 
                type="text" 
                value={manualAddress} 
                onChange={(e) => setManualAddress(e.target.value)}
                placeholder="Specific landmark or street address..."
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-black text-slate-800 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all"
              />
              <svg className="w-4 h-4 text-slate-300 absolute right-4 top-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth="2"/></svg>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Detected Type</p>
                <p className="text-xs font-black text-slate-900">{analysis?.detectedType || 'Other'}</p>
             </div>
             <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Severity Tier</p>
                <p className="text-xs font-black text-red-600">{analysis?.severity || 'Medium'}</p>
             </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Field Narrative</label>
            <textarea 
              value={description} 
              onChange={(e) => setDescription(e.target.value)} 
              placeholder="Describe physical signs, odors, or sounds noticed..." 
              className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-6 font-bold text-slate-900 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all min-h-[120px]" 
            />
          </div>

          <button onClick={handleSubmit} className="w-full bg-emerald-600 text-white font-black py-5 rounded-[2rem] shadow-2xl hover:bg-emerald-700 active:scale-[0.98] transition-all">Submit Secure Report</button>
        </div>
      )}
    </div>
  );
};

export default ReportWizard;
