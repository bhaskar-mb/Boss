
import React, { useState } from 'react';
import { loginUser, registerUser } from '../services/authService';
import { User, UserRole } from '../types';

const AUTHORITIES = ["Forestry Commission", "Wildlife Rescue Unit", "EPA Response Team", "Municipal Parks Dept"];

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [role, setRole] = useState<UserRole>('user');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successStep, setSuccessStep] = useState(0); 
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [org, setOrg] = useState(AUTHORITIES[0]);

  const handleRegister = async () => {
    setLoading(true);
    setError('');
    try {
      const newUser = await registerUser(name, email, role, role === 'authority' ? org : undefined);
      setSuccessStep(1);
      setTimeout(() => setSuccessStep(2), 1500);
      setTimeout(() => {
        onLoginSuccess(newUser);
      }, 3000);
    } catch (err: any) {
      setError(err.message || "Registration failed.");
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      const user = await loginUser(email, password, role);
      onLoginSuccess(user);
    } catch (err: any) {
      setError(err.message || "Invalid credentials.");
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegister) {
      handleRegister();
    } else {
      handleLogin();
    }
  };

  const getHint = () => {
    if (role === 'admin') return { e: 'admin@ecoguard.ai', p: 'admin' };
    if (role === 'authority') return { e: 'forestry@agency.gov', p: 'forest' };
    return { e: 'user@test.com', p: 'user' };
  };

  const applyHint = () => {
    const hint = getHint();
    setEmail(hint.e);
    setPassword(hint.p);
  };

  if (successStep > 0) {
    return (
      <div className="min-h-screen bg-[#061e1a] flex items-center justify-center p-6">
        <div className="w-full max-w-lg bg-white rounded-[3rem] p-12 text-center shadow-2xl animate-slide-up">
          {successStep === 1 ? (
            <div className="space-y-8 py-10">
              <div className="w-20 h-20 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
              <h2 className="text-2xl font-black text-slate-900">Synchronizing...</h2>
              <p className="text-slate-500 font-medium">Connecting to Environmental Intelligence Grid</p>
            </div>
          ) : (
            <div className="space-y-8 py-10 animate-in fade-in zoom-in duration-500">
              <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto text-white shadow-lg shadow-emerald-200">
                <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M5 13l4 4L19 7" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
              <h2 className="text-3xl font-black text-slate-900 mb-2">Authenticated</h2>
              <p className="text-slate-500 font-medium">Entering secure role-based Command Center...</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-1000 flex flex-col items-center justify-center p-6 relative overflow-hidden ${
      role === 'admin' ? 'bg-[#0f172a]' : role === 'authority' ? 'bg-[#291e0a]' : 'bg-[#061e1a]'
    }`}>
      <div className="w-full max-w-lg bg-white/95 backdrop-blur-2xl rounded-[3rem] p-10 shadow-2xl relative z-10 border border-white/20 animate-slide-up">
        
        <div className="flex bg-slate-100 p-1 rounded-2xl mb-8">
          {(['user', 'admin', 'authority'] as UserRole[]).map((r) => (
            <button 
              key={r}
              type="button"
              onClick={() => { setRole(r); setError(''); }}
              className={`flex-1 py-3 px-2 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all ${
                role === r ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              {r === 'authority' ? 'Agency' : r}
            </button>
          ))}
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-black text-slate-900 mb-2">EcoGuardian <span className={role === 'admin' ? 'text-indigo-600' : role === 'authority' ? 'text-amber-600' : 'text-emerald-600'}>AI</span></h1>
          <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em]">Operational Role: {role === 'authority' ? 'Response Agency' : role}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <>
              <input 
                type="text" required value={name} onChange={(e) => setName(e.target.value)} 
                placeholder="Display Name" 
                className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 outline-none transition-all" 
              />
              {role === 'authority' && (
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-2">Select Agency Unit</label>
                  <select 
                    value={org} 
                    onChange={(e) => setOrg(e.target.value)}
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 outline-none transition-all appearance-none"
                  >
                    {AUTHORITIES.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
              )}
            </>
          )}
          <input 
            type="email" required value={email} onChange={(e) => setEmail(e.target.value)} 
            placeholder="System Email" 
            className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 outline-none transition-all" 
          />
          <input 
            type="password" required value={password} onChange={(e) => setPassword(e.target.value)} 
            placeholder="Security Pin" 
            className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 outline-none transition-all" 
          />

          {error && <div className="bg-red-50 text-red-600 text-[10px] font-black p-4 rounded-xl border border-red-100">{error}</div>}

          <button disabled={loading} type="submit" className={`w-full py-5 rounded-2xl font-black text-white shadow-xl transition-all active:scale-95 disabled:opacity-50 ${
            role === 'admin' ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200' : 
            role === 'authority' ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-200' : 
            'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200'
          }`}>
            {loading ? 'Authenticating...' : isRegister ? 'Join Network' : 'Enter Command Center'}
          </button>
        </form>

        <div className="mt-8 p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center">
           <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Recruiter Test Access</p>
           <button 
             onClick={applyHint}
             className="text-[10px] font-bold text-slate-600 hover:text-slate-900 underline decoration-slate-300 transition-all"
           >
             Apply {role} credentials automatically
           </button>
        </div>

        <button 
          onClick={() => { setIsRegister(!isRegister); setError(''); }} 
          className="w-full mt-6 text-[9px] font-black text-slate-400 hover:text-slate-600 uppercase tracking-widest"
        >
          {isRegister ? 'Agent Log-in' : 'New Recruitment Application'}
        </button>
      </div>
    </div>
  );
};

export default Login;
