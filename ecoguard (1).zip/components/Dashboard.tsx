
import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { generateCommunityUpdate } from '../services/geminiService';
import { Report, User } from '../types';

const data = [
  { name: 'Mon', incidents: 12 },
  { name: 'Tue', incidents: 19 },
  { name: 'Wed', incidents: 14 },
  { name: 'Thu', incidents: 32 },
  { name: 'Fri', incidents: 22 },
  { name: 'Sat', incidents: 45 },
  { name: 'Sun', incidents: 28 },
];

interface DashboardProps {
  reports: Report[];
  user: User;
  onNewReport: () => void;
  onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ reports, user, onNewReport, onNavigate }) => {
  const [aiSummary, setAiSummary] = useState("AI is cross-referencing recent environmental data...");

  useEffect(() => {
    const fetchSummary = async () => {
      if (reports.length > 0) {
        try {
          const summary = await generateCommunityUpdate(reports.slice(0, 5));
          setAiSummary(summary);
        } catch (e) {
          setAiSummary("The sentinel network remains active. Your reports provide critical data points for wildlife safety.");
        }
      }
    };
    fetchSummary();
  }, [reports]);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
      {/* Premium Hero */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-950 to-[#061e1a] rounded-[3.5rem] p-10 md:p-16 text-white shadow-3xl shadow-emerald-900/20">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] animate-pulse" />

        <div className="relative z-10 flex flex-col xl:flex-row xl:items-center justify-between gap-12">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] mb-8 text-emerald-400">
               <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
               Live Operational Status
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-[1.05] tracking-tight">Safeguarding <br/> Natural Capital.</h1>
            
            <div className="flex flex-wrap gap-4 mb-10">
              <button 
                onClick={onNewReport}
                className="bg-emerald-600 text-white px-10 py-5 rounded-2xl font-black hover:bg-emerald-500 transition-all flex items-center gap-3 shadow-2xl shadow-emerald-900/40 active:scale-95 text-lg"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 4v16m8-8H4" strokeWidth="4" strokeLinecap="round"/></svg>
                Deploy Sentinel Report
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button onClick={() => onNavigate('notes')} className="flex items-center gap-4 p-5 bg-white/5 backdrop-blur-md border border-white/10 rounded-[2rem] hover:bg-white/10 transition-all text-left group">
                <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" strokeWidth="2"/></svg>
                </div>
                <div>
                  <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Library</p>
                  <p className="text-sm font-bold">Field Notes</p>
                </div>
              </button>

              <button onClick={() => onNavigate('notes')} className="flex items-center gap-4 p-5 bg-white/5 backdrop-blur-md border border-white/10 rounded-[2rem] hover:bg-white/10 transition-all text-left group">
                <div className="w-12 h-12 bg-amber-500/20 rounded-xl flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                   <span className="text-xl">🐾</span>
                </div>
                <div>
                  <p className="text-[10px] font-black text-amber-400 uppercase tracking-widest">Wildlife</p>
                  <p className="text-sm font-bold">Risk Tracker</p>
                </div>
              </button>

              <button onClick={() => onNavigate('notes')} className="flex items-center gap-4 p-5 bg-white/5 backdrop-blur-md border border-white/10 rounded-[2rem] hover:bg-white/10 transition-all text-left group">
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                   <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" strokeWidth="2"/></svg>
                </div>
                <div>
                  <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Governance</p>
                  <p className="text-sm font-bold">Gov Portals</p>
                </div>
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-6 xl:w-80">
             <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-[2.5rem]">
                <p className="text-emerald-400 text-[10px] font-black uppercase tracking-widest mb-2">Network Status</p>
                <p className="text-xl font-black text-white mb-1">Active Sentinel</p>
                <p className="text-[9px] text-white/40 font-bold uppercase tracking-widest">Range: 25km Radius</p>
             </div>
             <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-[2.5rem]">
                <p className="text-amber-400 text-[10px] font-black uppercase tracking-widest mb-2">Current Points</p>
                <p className="text-4xl font-black tracking-tighter text-white">{user.points}</p>
             </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-10">
            <div>
               <h3 className="font-black text-2xl text-slate-900">Regional Environmental Activity</h3>
               <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Incident Trends in your Sector</p>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 900}} />
                <YAxis hide />
                <Tooltip />
                <Area type="monotone" dataKey="incidents" stroke="#10b981" strokeWidth={4} fill="#10b981" fillOpacity={0.05} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 rounded-[3rem] p-10 text-white flex flex-col justify-between">
          <div className="space-y-8">
            <div className="flex items-center gap-4">
               <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center text-emerald-400 border border-white/10">
                 <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M13 10V3L4 14h7v7l9-11h-7z" strokeWidth="2.5"/></svg>
               </div>
               <div>
                 <h3 className="font-black text-xl">Command AI</h3>
                 <p className="text-[10px] font-black uppercase text-emerald-400 tracking-widest">Intelligence Feed</p>
               </div>
            </div>
            <p className="text-slate-400 font-bold italic leading-relaxed text-lg">"{aiSummary}"</p>
          </div>
          <button onClick={() => onNavigate('notes')} className="w-full py-5 bg-emerald-600 rounded-2xl text-white font-black text-sm hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-900/40">
            View Field Protocols
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
