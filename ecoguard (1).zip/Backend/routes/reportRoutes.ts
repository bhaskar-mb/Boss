
import express from 'express';
import * as reportController from '../controllers/reportController';

const router = express.Router();

router.get('/', reportController.getAllReports);
router.post('/', reportController.createReport);
router.patch('/:id/status', reportController.updateReportStatus);

export default router;
