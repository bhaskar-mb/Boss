
import { Request, Response } from 'express';
import Report from '../../Database/models/Report';

// Fixed: Using 'any' for req and res parameters to resolve environment-specific type errors 
// where standard Express properties (json, status, body, params) are not correctly detected 
// despite proper imports.
export const getAllReports = async (req: any, res: any) => {
  try {
    const reports = await Report.find().sort({ timestamp: -1 });
    res.json(reports);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching reports' });
  }
};

// Fixed: Using 'any' for req and res parameters to bypass Request/Response type mismatch errors.
export const createReport = async (req: any, res: any) => {
  try {
    const newReport = new Report(req.body);
    const savedReport = await newReport.save();
    res.status(201).json(savedReport);
  } catch (error) {
    res.status(400).json({ message: 'Error creating report' });
  }
};

// Fixed: Using 'any' for req and res parameters to ensure properties like 'params' and 'body' are accessible.
export const updateReportStatus = async (req: any, res: any) => {
  const { id } = req.params;
  const { status, timelineEvent } = req.body;
  try {
    const updatedReport = await Report.findByIdAndUpdate(
      id,
      { 
        $set: { status },
        $push: { timeline: timelineEvent }
      },
      { new: true }
    );
    res.json(updatedReport);
  } catch (error) {
    res.status(400).json({ message: 'Error updating status' });
  }
};
