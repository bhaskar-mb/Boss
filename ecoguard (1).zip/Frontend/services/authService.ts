
import { User, UserRole } from "../types.ts";

const MOCK_DB: Record<string, User & { password?: string }> = {
  'admin@ecoguard.org': {
    id: 'admin-001',
    name: 'Chief Warden',
    email: 'admin@ecoguard.org',
    role: 'admin',
    points: 0,
    reportsCount: 0,
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Admin',
    password: 'admin'
  },
  'forestry@agency.gov': {
    id: 'auth-001',
    name: 'Sector Manager',
    email: 'forestry@agency.gov',
    role: 'authority',
    organization: 'Forestry Commission',
    points: 0,
    reportsCount: 15,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Forestry',
    password: 'forest'
  },
  'wildlife@agency.gov': {
    id: 'auth-002',
    name: 'Sarah Rescue',
    email: 'wildlife@agency.gov',
    role: 'authority',
    organization: 'Wildlife Rescue Unit',
    points: 0,
    reportsCount: 28,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    password: 'rescue'
  },
  'epa@agency.gov': {
    id: 'auth-003',
    name: 'Inspector Miller',
    email: 'epa@agency.gov',
    role: 'authority',
    organization: 'EPA Response Team',
    points: 0,
    reportsCount: 12,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=EPA',
    password: 'epa'
  },
  'parks@agency.gov': {
    id: 'auth-004',
    name: 'Park Ranger Dave',
    email: 'parks@agency.gov',
    role: 'authority',
    organization: 'Municipal Parks Dept',
    points: 0,
    reportsCount: 5,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Parks',
    password: 'parks'
  },
  'user@test.com': {
    id: 'user-001',
    name: 'John Sentinel',
    email: 'user@test.com',
    role: 'user',
    points: 450,
    reportsCount: 4,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
    password: 'user'
  }
};

export const loginUser = async (email: string, password: string, role: UserRole): Promise<User> => {
  await new Promise(resolve => setTimeout(resolve, 800));
  const user = MOCK_DB[email.toLowerCase()];
  
  if (!user || user.role !== role || (user.password && user.password !== password)) {
    throw new Error("Invalid credentials or unauthorized role access.");
  }

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    points: user.points,
    reportsCount: user.reportsCount,
    avatar: user.avatar,
    organization: user.organization
  };
};

export const registerUser = async (name: string, email: string, role: UserRole, organization?: string): Promise<User> => {
  await new Promise(resolve => setTimeout(resolve, 1000));

  if (MOCK_DB[email.toLowerCase()]) {
    throw new Error("User already exists with this email.");
  }

  const newUser: User = {
    id: `u-${Math.random().toString(36).substr(2, 5)}`,
    name,
    email: email.toLowerCase(),
    role,
    points: role === 'user' ? 100 : 0,
    reportsCount: 0,
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
    // If authority, ensure an organization is assigned (defaults to first available if none provided)
    organization: role === 'authority' ? (organization || 'Forestry Commission') : undefined
  };

  MOCK_DB[email.toLowerCase()] = { ...newUser };
  return newUser;
};
