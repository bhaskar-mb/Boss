
import React, { useState, useMemo, useRef } from 'react';
import Layout from './components/Layout.tsx';
import Dashboard from './components/Dashboard.tsx';
import ReportWizard from './components/ReportWizard.tsx';
import Login from './components/Login.tsx';
import SystemInsights from './components/SystemInsights.tsx';
import Resources from './components/Resources.tsx';
import ChatSentinel from './components/ChatSentinel.tsx';
import { User, Report, Severity, IncidentType, ReportStatus, TimelineEvent } from './types.ts';

const AUTHORITIES = ["Forestry Commission", "Wildlife Rescue Unit", "EPA Response Team", "Municipal Parks Dept"];

const INITIAL_REPORTS: Report[] = [
  {
    id: 'R-902',
    type: IncidentType.ILLEGAL_LOGGING,
    severity: Severity.HIGH,
    description: 'Fresh tree stumps and heavy tire marks detected in the protected buffer zone.',
    location: { lat: 45.523, lng: -122.676, address: "Northern Ridge Biosphere, Sector 7" },
    timestamp: new Date(Date.now() - 7200000),
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800',
    status: 'assigned',
    reporterId: 'user-001',
    assignedAuthorityId: 'Forestry Commission',
    aiInsights: 'Vision analysis confirms recent logging activity in a restricted zone.',
    timeline: [
      { status: 'pending', timestamp: new Date(Date.now() - 7200000), message: 'Incident reported by Sentinel.', actor: 'John Sentinel' },
      { status: 'assigned', timestamp: new Date(Date.now() - 3600000), message: 'Admin assigned case to Forestry Commission.', actor: 'Chief Warden' }
    ]
  }
];

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [reports, setReports] = useState<Report[]>(INITIAL_REPORTS);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [agencyActionText, setAgencyActionText] = useState('');
  const [agencyProofImage, setAgencyProofImage] = useState<string | null>(null);
  const [showOtherAgencyInput, setShowOtherAgencyInput] = useState<string | null>(null); // reportId if active
  const [otherAgencyName, setOtherAgencyName] = useState('');
  
  const proofInputRef = useRef<HTMLInputElement>(null);

  const handleAuthSuccess = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    setIsAuthenticated(true);
  };

  const handleUpdateStatus = (id: string, newStatus: ReportStatus, message: string, actor: string, extraData?: any) => {
    setReports(prev => prev.map(r => {
      if (r.id === id) {
        const newEvent: TimelineEvent = { 
          status: newStatus, 
          timestamp: new Date(), 
          message, 
          actor, 
          actionTaken: extraData?.actionTaken 
        };
        return { 
          ...r, 
          status: newStatus, 
          timeline: [...r.timeline, newEvent], 
          ...extraData 
        };
      }
      return r;
    }));
    setAgencyActionText('');
    setAgencyProofImage(null);
    setShowOtherAgencyInput(null);
    setOtherAgencyName('');
  };

  const handleProofUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setAgencyProofImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const visibleReports = useMemo(() => {
    if (!user) return [];
    switch (user.role) {
      case 'admin': return reports;
      case 'authority': return reports.filter(r => r.assignedAuthorityId === user.organization);
      case 'user': return reports.filter(r => r.reporterId === user.id);
      default: return [];
    }
  }, [reports, user]);

  if (!isAuthenticated) return <Login onLoginSuccess={handleAuthSuccess} />;

  return (
    <Layout user={user!} onLogout={() => setIsAuthenticated(false)} activeTab={activeTab} setActiveTab={setActiveTab}>
      
      {activeTab === 'dashboard' && <Dashboard reports={reports} user={user!} onNewReport={() => setActiveTab('report')} onNavigate={(t) => setActiveTab(t)} />}
      
      {activeTab === 'report' && user?.role === 'user' && (
        <ReportWizard onComplete={(data) => {
          const nr: Report = { 
            ...data, 
            id: `R-${Math.floor(Math.random() * 900) + 100}`, 
            status: 'pending', 
            reporterId: user!.id, 
            timeline: [{ 
              status: 'pending', 
              timestamp: new Date(), 
              message: 'Incident reported. Dispatched to Global Command for triage.', 
              actor: user!.name 
            }] 
          } as Report;
          setReports([nr, ...reports]);
          setActiveTab('reports');
        }} />
      )}

      {activeTab === 'reports' && (
        <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          <div className="bg-[#0f172a] p-12 rounded-[4rem] border border-white/5 shadow-2xl flex flex-col md:flex-row justify-between items-center gap-8">
             <div className="flex items-center gap-8">
                <div className={`w-20 h-20 rounded-3xl flex items-center justify-center shadow-2xl ${
                  user?.role === 'admin' ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30' : 
                  user?.role === 'authority' ? 'bg-amber-600/20 text-amber-400 border border-amber-500/30' : 
                  'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30'
                }`}>
                   <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      {user?.role === 'admin' ? <path d="M12 21l-8-4.5v-9L12 3l8 4.5v9l-8 4.5z" strokeWidth="2"/> : 
                       user?.role === 'authority' ? <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeWidth="2"/> :
                       <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" strokeWidth="2"/>}
                   </svg>
                </div>
                <div>
                  <h2 className="text-4xl font-black text-white tracking-tighter">
                    {user?.role === 'admin' ? 'Admin' : 
                     user?.role === 'authority' ? 'Authority' : 'User'}
                  </h2>
                  <p className="text-slate-400 font-medium mt-1">
                    {user?.role === 'admin' ? 'Incident triage and final verification nexus.' : 
                     user?.role === 'authority' ? `Operational interface for ${user.organization}.` : 'Secure channel for environmental reporting.'}
                  </p>
                </div>
             </div>
          </div>

          <div className="grid gap-16">
            {visibleReports.length === 0 ? (
              <div className="text-center py-24 bg-[#0f172a]/40 rounded-[4rem] border border-dashed border-white/5">
                 <p className="font-black text-slate-500 uppercase tracking-widest text-xl">No Active Reports in Sector</p>
              </div>
            ) : (
              visibleReports.map(r => (
                <div key={r.id} className="bg-[#0f172a] rounded-[4rem] border border-white/5 shadow-3xl overflow-hidden flex flex-col group transition-all duration-500 hover:border-emerald-500/20">
                   
                   {/* Main Header Information */}
                   <div className="p-12 pb-0 flex flex-col md:flex-row justify-between gap-8">
                      <div className="space-y-4">
                        <div className="flex items-center gap-4">
                           <span className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest text-white ${
                             r.severity === Severity.CRITICAL ? 'bg-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)]' : 
                             r.severity === Severity.HIGH ? 'bg-orange-500' : 'bg-emerald-500'
                           }`}>{r.type}</span>
                           <div className={`w-3.5 h-3.5 rounded-full shadow-lg ${
                             r.status === 'resolved' ? 'bg-emerald-500' : 
                             r.status === 'solved_by_authority' ? 'bg-blue-500 animate-pulse' : 
                             r.status === 'assigned' ? 'bg-amber-500' : 'bg-slate-400'
                           }`} />
                           <p className="text-xs font-black text-slate-400 uppercase tracking-widest">
                             Status: <span className="text-white">{r.status.replace('_', ' ')}</span>
                           </p>
                        </div>
                        
                        <div className="flex items-center gap-3 text-emerald-400">
                           <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" strokeWidth="2"/><path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" strokeWidth="2"/></svg>
                           <h3 className="text-white text-3xl font-black tracking-tighter leading-none">{r.location.address}</h3>
                        </div>

                        <p className="text-xl font-bold text-slate-400 max-w-2xl italic leading-relaxed border-l-4 border-white/10 pl-6">"{r.description}"</p>
                      </div>
                      <div className="text-right">
                         <div className="text-[10px] font-black text-slate-500 tracking-[0.2em] bg-white/5 px-4 py-2 rounded-xl border border-white/5 inline-block">ID: {r.id}</div>
                         <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mt-4">Reported: {new Date(r.timestamp).toLocaleDateString()}</p>
                      </div>
                   </div>

                   {/* Visual Evidence Area */}
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-12">
                      <div className="space-y-4">
                         <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Incident Evidence</p>
                         <div className="aspect-video relative rounded-[2.5rem] overflow-hidden border border-white/5">
                            <img src={r.imageUrl} className="w-full h-full object-cover" alt="Before" />
                         </div>
                      </div>
                      
                      {(r.status === 'solved_by_authority' || r.status === 'resolved') ? (
                        <div className="space-y-4 animate-in fade-in zoom-in duration-700">
                           <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest pl-2">Field Resolution Proof</p>
                           <div className="aspect-video relative rounded-[2.5rem] overflow-hidden border border-emerald-500/20">
                              <img src={r.resolvedImageUrl} className="w-full h-full object-cover" alt="After" />
                           </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center bg-white/5 rounded-[2.5rem] border border-dashed border-white/10">
                           <p className="text-slate-600 font-black text-xs uppercase tracking-widest">Awaiting Field Action...</p>
                        </div>
                      )}
                   </div>

                   {/* Protocol & Action Area */}
                   <div className="px-12 pb-12">
                      {/* ADMIN PROTOCOL */}
                      {user?.role === 'admin' && (
                        <div className="bg-indigo-500/5 p-10 rounded-[3rem] border border-indigo-500/10 space-y-10">
                           {r.status === 'pending' && (
                             <div className="space-y-8 animate-in slide-in-from-top-2 duration-500">
                               <h4 className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.25em] pl-2">Dispatch Protocol: Assign Specialized Unit</h4>
                               
                               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                 {AUTHORITIES.map(auth => (
                                   <button key={auth} 
                                     onClick={() => handleUpdateStatus(r.id, 'assigned', `Admin triaged and deployed ${auth}.`, 'Chief Warden', { assignedAuthorityId: auth })}
                                     className="px-8 py-6 bg-indigo-600 text-white rounded-full text-xs font-black uppercase tracking-widest hover:bg-indigo-500 transition-all shadow-[0_15px_30px_-5px_rgba(79,70,229,0.4)] active:scale-95 text-center"
                                   >Deploy {auth}</button>
                                 ))}
                                 
                                 {/* OTHER/CUSTOM OPTION */}
                                 <button 
                                   onClick={() => setShowOtherAgencyInput(r.id)}
                                   className="px-8 py-6 bg-slate-800 text-slate-300 border border-slate-700 rounded-full text-xs font-black uppercase tracking-widest hover:bg-slate-700 transition-all active:scale-95 text-center"
                                 >Other Response Unit</button>
                               </div>

                               {showOtherAgencyInput === r.id && (
                                 <div className="mt-8 p-8 bg-slate-900/50 rounded-[2.5rem] border border-indigo-500/20 animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-6">
                                    <p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">Specify Custom Authority Name:</p>
                                    <div className="flex gap-4">
                                      <input 
                                        type="text" 
                                        value={otherAgencyName}
                                        onChange={(e) => setOtherAgencyName(e.target.value)}
                                        placeholder="Enter Agency Name (e.g. Coast Guard, City Drainage Team)"
                                        className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-4 font-bold text-white focus:ring-4 focus:ring-indigo-500/20 outline-none"
                                      />
                                      <button 
                                        disabled={!otherAgencyName.trim()}
                                        onClick={() => handleUpdateStatus(r.id, 'assigned', `Admin deployed special unit: ${otherAgencyName}.`, 'Chief Warden', { assignedAuthorityId: otherAgencyName })}
                                        className="px-10 py-4 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-500 disabled:opacity-30 transition-all shadow-xl shadow-emerald-900/40"
                                      >Deploy Now</button>
                                    </div>
                                 </div>
                               )}
                             </div>
                           )}

                           {r.status === 'solved_by_authority' && (
                             <div className="space-y-8">
                               <div className="bg-white/5 p-8 rounded-[2rem] border border-indigo-500/20">
                                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-4">Agency Closure Report:</p>
                                  <p className="text-lg font-bold text-slate-100 italic">"{r.resolutionDetails}"</p>
                               </div>
                               <div className="flex gap-4">
                                  <button 
                                    onClick={() => handleUpdateStatus(r.id, 'resolved', 'Admin verified the manual field fix and documentation. User notified.', 'Chief Warden')}
                                    className="flex-1 py-5 bg-emerald-600 text-white rounded-full font-black text-[10px] uppercase tracking-widest hover:bg-emerald-500 shadow-2xl shadow-emerald-900/40 transition-all flex items-center justify-center gap-3"
                                  >Verify Proof & Close Incident</button>
                               </div>
                             </div>
                           )}
                        </div>
                      )}

                      {/* AGENCY PROTOCOL: Manual Field Fix + Completion Photo */}
                      {user?.role === 'authority' && (
                        <div className="bg-amber-500/5 p-10 rounded-[3rem] border border-amber-500/10 space-y-8">
                           {r.status === 'assigned' && (
                             <div className="space-y-8">
                               <div className="flex items-center justify-between">
                                  <p className="text-[10px] font-black text-amber-400 uppercase tracking-widest">Operational Task: Manual Field Intervention</p>
                                  <span className="text-[10px] font-black text-slate-600">MANDATORY DOCUMENTATION</span>
                               </div>
                               
                               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                  <div className="space-y-4">
                                     <p className="text-xs font-bold text-slate-400 pl-2">1. Resolution Summary</p>
                                     <textarea 
                                        value={agencyActionText}
                                        onChange={(e) => setAgencyActionText(e.target.value)}
                                        placeholder="Detail the field work (e.g. 'Cleared drainage, replaced grate')..."
                                        className="w-full bg-white/5 border border-white/10 rounded-3xl p-6 font-bold text-white focus:ring-4 focus:ring-amber-500/10 outline-none transition-all min-h-[160px]"
                                     />
                                  </div>
                                  <div className="space-y-4">
                                     <p className="text-xs font-bold text-slate-400 pl-2">2. Completion Photo (After)</p>
                                     <div 
                                        onClick={() => proofInputRef.current?.click()}
                                        className="w-full aspect-video bg-white/5 border-2 border-dashed border-white/10 rounded-3xl flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 transition-all overflow-hidden relative group"
                                     >
                                        {agencyProofImage ? (
                                          <img src={agencyProofImage} className="w-full h-full object-cover" />
                                        ) : (
                                          <div className="text-center">
                                             <svg className="w-12 h-12 text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth="2"/></svg>
                                             <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Upload Documentation</p>
                                          </div>
                                        )}
                                        <input type="file" hidden ref={proofInputRef} onChange={handleProofUpload} accept="image/*" />
                                     </div>
                                  </div>
                               </div>

                               <button 
                                  disabled={!agencyActionText.trim() || !agencyProofImage}
                                  onClick={() => handleUpdateStatus(r.id, 'solved_by_authority', `Field Work Complete: ${agencyActionText}`, user.organization || 'Agency', { resolutionDetails: agencyActionText, resolvedImageUrl: agencyProofImage, resolvedTimestamp: new Date() })}
                                  className="w-full py-6 bg-amber-600 text-white rounded-full font-black text-xs uppercase tracking-[0.2em] hover:bg-amber-500 disabled:opacity-30 transition-all shadow-2xl shadow-amber-900/60 active:scale-95"
                                >Intimate Field Resolution to Command</button>
                             </div>
                           )}
                        </div>
                      )}

                      {/* USER FEEDBACK */}
                      {user?.role === 'user' && (
                        <div className="bg-emerald-500/5 p-12 rounded-[4rem] border border-emerald-500/10">
                           <div className="flex flex-col md:flex-row items-center gap-12">
                              <div className={`w-32 h-32 rounded-[2.5rem] flex items-center justify-center text-white shadow-3xl transition-all duration-1000 ${
                                r.status === 'resolved' ? 'bg-emerald-500 scale-110' : 'bg-slate-700'
                              }`}>
                                 {r.status === 'resolved' ? <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="4"/></svg> : <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="4"/></svg>}
                              </div>
                              <div className="flex-1 text-center md:text-left">
                                 <h4 className="text-4xl font-black text-white tracking-tighter mb-4">
                                   {r.status === 'pending' && "Evidence Received."}
                                   {r.status === 'assigned' && "Agency Dispatched."}
                                   {r.status === 'solved_by_authority' && "Field Work Done."}
                                   {r.status === 'resolved' && "Incident Restored."}
                                 </h4>
                                 <p className="text-xl text-slate-400 font-bold leading-relaxed mb-6">
                                   {r.status === 'pending' && "Sentinel AI has verified the coordinates. Command is triaging for unit dispatch."}
                                   {r.status === 'assigned' && `The ${r.assignedAuthorityId} unit is physically at the site for restoration.`}
                                   {r.status === 'solved_by_authority' && "Documentation is being reviewed by Command for final approval."}
                                   {r.status === 'resolved' && "Restoration complete. Impact Points Awarded!"}
                                 </p>
                              </div>
                           </div>
                        </div>
                      )}
                   </div>

                   {/* Timeline Footer */}
                   <div className="bg-black/20 p-12 border-t border-white/5">
                      <div className="flex items-center gap-10">
                        <div className="flex-1 space-y-6 relative pl-10">
                           <div className="absolute left-[5px] top-2 bottom-2 w-0.5 bg-white/5" />
                           {r.timeline.map((evt, idx) => (
                             <div key={idx} className="relative">
                                <div className={`absolute -left-[40px] top-1.5 w-4 h-4 rounded-full border-4 border-[#0f172a] shadow-sm ${
                                  idx === r.timeline.length-1 ? (evt.status === 'resolved' ? 'bg-emerald-500' : 'bg-indigo-500') : 'bg-slate-700'
                                }`} />
                                <div className="flex justify-between items-center">
                                   <div>
                                      <p className="text-sm font-black text-white tracking-tight leading-none">{evt.message}</p>
                                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1">Personnel: <span className="text-slate-300">{evt.actor}</span></p>
                                   </div>
                                   <span className="text-[10px] font-bold text-slate-600 bg-white/5 px-2 py-1 rounded-lg">{new Date(evt.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                </div>
                             </div>
                           ))}
                        </div>
                      </div>
                   </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {activeTab === 'notes' && <Resources />}
      {activeTab === 'leaderboard' && <SystemInsights />}
      
      {/* Global AI Chat Sentinel */}
      <ChatSentinel user={user!} />
    </Layout>
  );
};

export default App;
