import React from 'react';

const SystemInsights: React.FC = () => {
  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-4">Architecture Deep-Dive</h2>
        <p className="text-slate-500 font-medium">This project demonstrates a production-grade full-stack architecture optimized for low-latency AI vision processing.</p>
      </div>

      {/* Visual Tech Stack */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -mr-10 -mt-10 group-hover:scale-110 transition-transform" />
          <div className="relative z-10">
            <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 21l-8-4.5v-9L12 3l8 4.5v9l-8 4.5z" strokeWidth="1.5"/></svg>
            </div>
            <h3 className="text-xl font-black text-slate-800 mb-2">Frontend</h3>
            <p className="text-sm font-bold text-slate-400 mb-6">React 19 + Tailwind CSS</p>
            <ul className="space-y-3">
              {['Google Identity Integration', 'Vision Buffer Management', 'Glassmorphism UI System', 'Responsive Sentinel Feed'].map(item => (
                <li key={item} className="flex items-center gap-2 text-xs font-bold text-slate-600">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-[#0f172a] p-8 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group">
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full -ml-10 -mb-10 group-hover:scale-110 transition-transform" />
          <div className="relative z-10">
            <div className="w-14 h-14 bg-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400 mb-6 border border-indigo-500/30">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth="1.5"/></svg>
            </div>
            <h3 className="text-xl font-black mb-2">Backend</h3>
            <p className="text-sm font-bold text-slate-400 mb-6">Node.js + Express</p>
            <ul className="space-y-3">
              {['JWT Token Validation', 'Gemini AI Vision Proxy', 'Cloudinary Image Handling', 'RESTful API Controllers'].map(item => (
                <li key={item} className="flex items-center gap-2 text-xs font-bold text-slate-300">
                  <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full" /> {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-32 h-32 bg-amber-50 rounded-full -ml-10 -mt-10 group-hover:scale-110 transition-transform" />
          <div className="relative z-10 text-right">
             <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 mb-6 ml-auto">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" strokeWidth="1.5"/></svg>
            </div>
            <h3 className="text-xl font-black text-slate-800 mb-2">Database</h3>
            <p className="text-sm font-bold text-slate-400 mb-6">MongoDB Atlas</p>
            <ul className="space-y-3 inline-block">
              {['Non-Relational Incident Logs', 'User Points & Rankings', 'Geospatial Query Support', 'Atomic Status Updates'].map(item => (
                <li key={item} className="flex items-center gap-2 text-xs font-bold text-slate-600 justify-end">
                  {item} <div className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Code Snippet Visual */}
      <div className="bg-slate-900 rounded-[3rem] p-8 md:p-12 overflow-hidden shadow-2xl">
         <div className="flex items-center gap-4 mb-8">
            <div className="flex gap-1.5">
               <div className="w-3 h-3 rounded-full bg-red-500" />
               <div className="w-3 h-3 rounded-full bg-amber-500" />
               <div className="w-3 h-3 rounded-full bg-emerald-500" />
            </div>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">controllers/reportController.js</span>
         </div>
         <pre className="text-xs md:text-sm font-mono text-emerald-400 leading-relaxed overflow-x-auto">
{`async function createReport(req, res) {
  const { type, severity, image } = req.body;
  
  // 1. Authenticate Request via Google JWT
  const user = await User.findById(req.userId);
  
  // 2. Persist Incident to MongoDB
  const newReport = await Report.create({
    type, 
    severity,
    imageUrl: await uploadToCloudinary(image),
    reporterId: user._id
  });

  // 3. Increment Gamification Points
  user.points += 100;
  await user.save();

  res.status(201).json(newReport);
}`}
         </pre>
      </div>
    </div>
  );
};

export default SystemInsights;