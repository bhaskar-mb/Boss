
import React, { useState, useEffect } from 'react';
import { EnvironmentalResource } from '../types.ts';

const RESOURCES: EnvironmentalResource[] = [
  // EMERGENCY CONTACTS
  { id: 'e1', title: 'Forest Fire Hotline', content: 'Urgent reports for wildfires or active illegal logging teams in protected sectors.', category: 'emergency', icon: '🔥', phone: '1-800-FIRE-ECO' },
  { id: 'e2', title: 'Wildlife Rescue Dispatch', content: 'Injured animals, human-wildlife conflict, or poaching sightings.', category: 'emergency', icon: '🐾', phone: '1-800-RESCUE-W' },
  { id: 'e3', title: 'Pollution Response', content: 'Toxic spills, industrial dumping, or massive water contamination alerts.', category: 'emergency', icon: '🛢️', phone: '0800-EPA-HELP' },
  { id: 'e4', title: 'Marine SOS', content: 'Stranded marine life, oil spills at sea, or illegal commercial fishing.', category: 'emergency', icon: '🐋', phone: '999-OCEAN-SOS' },
  { id: 'e5', title: 'National Park Police', content: 'Criminal activity, vandalism, or trespassing within national biosphere reserves.', category: 'emergency', icon: '🚓', phone: '1-800-RANGER-911' },

  // FIELD NOTES
  { id: 'n1', title: 'Elephant Corridor Safety', content: 'Recent migrations detected near highway 102. Avoid heavy noise and keep speed under 40kmph.', category: 'note', icon: '🐘' },
  { id: 'n2', title: 'Forest Fire Prevention', content: 'Dry season alert. Ensure no glass bottles are left in open sun. Report smoke instantly.', category: 'note', icon: '🔥' },
  { id: 'n3', title: 'Water Table Monitoring', content: 'Low groundwater levels detected in Sector 4. Limit non-essential agricultural irrigation until rainfall.', category: 'note', icon: '💧' },
  { id: 'n4', title: 'Pollinator Protection', content: 'Bee population decline noted in urban edges. Avoid pesticide use during early morning hours.', category: 'note', icon: '🐝' },
  { id: 'n5', title: 'Composting 101', content: 'Redirect 40% of household waste to soil regeneration. Avoid meat products in backyard bins.', category: 'note', icon: '🌱' },
  
  // WILDLIFE AT RISK
  { id: 'w1', title: 'Bengal Tiger (Endangered)', content: 'Estimated population: 3,500. Highly threatened by poaching and habitat fragmentation.', category: 'wildlife', icon: '🐅' },
  { id: 'w2', title: 'Olive Ridley Turtle', content: 'Nesting season starts in November. Keep beach lights off after 8 PM to guide hatchlings.', category: 'wildlife', icon: '🐢' },
  { id: 'w3', title: 'Vaquita (Critical)', content: 'World\'s rarest marine mammal. Only ~10 individuals left in the wild. Threatened by illegal gillnets.', category: 'wildlife', icon: '🐬' },
  { id: 'w4', title: 'Pangolin (Trafficked)', content: 'The most trafficked mammal globally. Hunted for scales used in traditional medicine.', category: 'wildlife', icon: '🐜' },
  { id: 'w5', title: 'Javan Rhino', content: 'Critically endangered with only one known population in Ujung Kulon National Park.', category: 'wildlife', icon: '🦏' },
  { id: 'w6', title: 'Snow Leopard', content: 'Ghost of the mountains. Vulnerable to climate change and human-wildlife conflict.', category: 'wildlife', icon: '🐆' },

  // GOVERNANCE LINKS
  { id: 'l1', title: 'Global Wildlife Fund', content: 'International body supporting wildlife conservation efforts globally.', category: 'link', url: 'https://www.worldwildlife.org' },
  { id: 'l2', title: 'EPA Official Portal', content: 'United States Environmental Protection Agency reporting and standards.', category: 'link', url: 'https://www.epa.gov' },
  { id: 'l3', title: 'UN Environment Programme', content: 'UN agency responsible for coordinating global environmental activities.', category: 'link', url: 'https://www.unep.org' },
  { id: 'l4', title: 'IUCN Red List', content: 'The world\'s most comprehensive inventory of biological species status.', category: 'link', url: 'https://www.iucnredlist.org' },
  { id: 'l5', title: 'CITES Secretariat', content: 'Convention on International Trade in Endangered Species of Wild Fauna and Flora.', category: 'link', url: 'https://cites.org' },
];

const Resources: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'note' | 'wildlife' | 'link' | 'emergency'>('all');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);

  // Load bookmarks from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('ecoguard_bookmarks');
    if (saved) {
      try {
        setBookmarkedIds(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load bookmarks");
      }
    }
  }, []);

  // Save bookmarks to local storage whenever they change
  const toggleBookmark = (id: string) => {
    const newBookmarks = bookmarkedIds.includes(id)
      ? bookmarkedIds.filter(bid => bid !== id)
      : [...bookmarkedIds, id];
    
    setBookmarkedIds(newBookmarks);
    localStorage.setItem('ecoguard_bookmarks', JSON.stringify(newBookmarks));
  };

  const filteredResources = filter === 'all' 
    ? RESOURCES 
    : RESOURCES.filter(r => r.category === filter);

  const categories = [
    { id: 'all', label: 'All Resources', icon: '🌐' },
    { id: 'emergency', label: 'SOS Contacts', icon: '🚨' },
    { id: 'note', label: 'Field Notes', icon: '📝' },
    { id: 'wildlife', label: 'Wildlife at Risk', icon: '🐾' },
    { id: 'link', label: 'Gov Portals', icon: '🏛️' },
  ];

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-700">
      {/* Header & Navigation */}
      <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Guardian Library</h2>
          <p className="text-slate-500 font-medium">Equipping the network with ecological intelligence.</p>
        </div>
        
        <div className="flex bg-slate-50 p-2 rounded-2xl border border-slate-200 gap-1 overflow-x-auto max-w-full">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id as any)}
              className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${
                filter === cat.id 
                  ? 'bg-slate-900 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span>{cat.icon}</span>
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Resource Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredResources.map((r) => {
          const isBookmarked = bookmarkedIds.includes(r.id);
          const isEmergency = r.category === 'emergency';
          
          return (
            <div key={r.id} className={`p-8 rounded-[2.5rem] border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group flex flex-col ${
              isEmergency ? 'bg-red-50 border-red-100 shadow-[0_20px_40px_rgba(239,68,68,0.05)]' : 'bg-white border-slate-100 shadow-sm'
            }`}>
              <div className="flex justify-between items-start mb-6">
                <div className="text-4xl transform group-hover:scale-110 transition-transform">{r.icon}</div>
                {r.category === 'link' && (
                  <a href={r.url} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center hover:bg-emerald-600 transition-colors">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" strokeWidth="2"/></svg>
                  </a>
                )}
                {isEmergency && (
                  <div className="w-12 h-12 bg-red-600 text-white rounded-2xl flex items-center justify-center animate-pulse shadow-xl shadow-red-900/30">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" strokeWidth="2.5"/></svg>
                  </div>
                )}
              </div>
              
              <span className={`text-[9px] font-black uppercase tracking-[0.2em] mb-2 ${
                isEmergency ? 'text-red-600' : r.category === 'note' ? 'text-emerald-500' : r.category === 'wildlife' ? 'text-amber-500' : 'text-indigo-500'
              }`}>
                {isEmergency ? 'Crisis Support Unit' : r.category === 'note' ? 'Field Guideline' : r.category === 'wildlife' ? 'Species at Risk' : 'Official Portal'}
              </span>
              
              <h4 className="text-xl font-black text-[#0f172a] mb-4">{r.title}</h4>
              <p className="text-sm text-slate-500 font-medium leading-relaxed flex-grow">{r.content}</p>
              
              {isEmergency && r.phone && (
                <a href={`tel:${r.phone}`} className="mt-8 py-5 bg-[#0f172a] text-white rounded-[1.5rem] text-center font-black text-sm uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10 active:scale-95">
                  Call {r.phone}
                </a>
              )}

              <div className="mt-8 pt-6 border-t border-slate-50 flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">ECO-REF-{r.id.toUpperCase()}</span>
                {!isEmergency && (
                  <button 
                    onClick={() => toggleBookmark(r.id)}
                    className={`text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 group/btn ${
                      isBookmarked ? 'text-emerald-600' : 'text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    <svg className={`w-4 h-4 transition-transform ${isBookmarked ? 'scale-110 fill-current' : 'group-hover/btn:scale-110'}`} viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                    {isBookmarked ? 'Saved' : 'Bookmark'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredResources.length === 0 && (
        <div className="py-20 text-center bg-slate-50 rounded-[3rem] border border-dashed border-slate-200">
          <p className="text-slate-400 font-black uppercase tracking-widest">No matching resources found in this sector.</p>
        </div>
      )}
    </div>
  );
};

export default Resources;
