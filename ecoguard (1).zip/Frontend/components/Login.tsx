
import React, { useState } from 'react';
import { loginUser, registerUser } from '../services/authService.ts';
import { User as UserType, UserRole } from '../types.ts';

const AUTHORITIES = ["Forestry Commission", "Wildlife Rescue Unit", "EPA Response Team", "Municipal Parks Dept"];

interface LoginProps {
  onLoginSuccess: (user: UserType) => void;
}

type AuthView = 'selector' | 'login' | 'register';

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [view, setView] = useState<AuthView>('selector');
  const [role, setRole] = useState<UserRole>('user');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [org, setOrg] = useState(AUTHORITIES[0]);

  const resetForms = () => {
    setEmail('');
    setPassword('');
    setName('');
    setError('');
  };

  const selectPortal = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setView('login');
    resetForms();
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (view === 'register') {
        const newUser = await registerUser(name, email, role, role === 'authority' ? org : undefined);
        onLoginSuccess(newUser);
      } else {
        const user = await loginUser(email, password, role);
        onLoginSuccess(user);
      }
    } catch (err: any) {
      setError(err.message || "Authentication failed.");
      setLoading(false);
    }
  };

  const getTheme = () => {
    switch(role) {
      case 'admin': return { 
        primary: 'indigo', 
        bg: 'bg-[#0f172a]', 
        text: 'text-indigo-400', 
        btn: 'bg-indigo-600 hover:bg-indigo-500', 
        accent: 'indigo-500/10',
        label: 'Admin'
      };
      case 'authority': return { 
        primary: 'amber', 
        bg: 'bg-[#1a1408]', 
        text: 'text-amber-400', 
        btn: 'bg-amber-600 hover:bg-amber-500', 
        accent: 'amber-500/10',
        label: 'Authority'
      };
      default: return { 
        primary: 'emerald', 
        bg: 'bg-[#061e1a]', 
        text: 'text-emerald-400', 
        btn: 'bg-emerald-600 hover:bg-emerald-500', 
        accent: 'emerald-500/10',
        label: 'User'
      };
    }
  };

  const theme = getTheme();

  if (view === 'selector') {
    return (
      <div className="min-h-screen bg-[#020617] flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none">
          <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-emerald-500/10 rounded-full blur-[140px]" />
          <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-indigo-500/10 rounded-full blur-[140px]" />
        </div>

        <div className="relative z-10 w-full max-w-7xl text-center space-y-16">
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-1000">
            <h1 className="text-6xl md:text-9xl font-black text-white tracking-tighter">
              EcoGuard
            </h1>
            <p className="text-slate-400 text-lg md:text-2xl font-medium tracking-wide max-w-2xl mx-auto opacity-70">
              Select your authorization node to enter the environmental grid.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-10 px-4">
            {/* User Portal */}
            <button 
              onClick={() => selectPortal('user')}
              className="group relative bg-[#0f172a] border border-white/5 p-12 rounded-[4rem] text-left hover:bg-[#131d36] hover:border-emerald-500/30 transition-all duration-500 hover:-translate-y-4 shadow-3xl"
            >
              <div className="w-20 h-20 bg-emerald-500/10 rounded-3xl flex items-center justify-center text-emerald-400 mb-10 group-hover:scale-110 transition-transform border border-emerald-500/20">
                <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" strokeWidth="2"/></svg>
              </div>
              <h3 className="text-4xl font-black text-white mb-4 tracking-tight">User</h3>
              <p className="text-slate-400 text-lg leading-relaxed mb-10 opacity-60">Report anomalies, injured wildlife, and ecosystem damage. Earn environmental credits.</p>
              <div className="text-emerald-500 text-xs font-black uppercase tracking-[0.3em] flex items-center gap-3 group-hover:gap-5 transition-all">
                ACCESS GLOBAL NETWORK <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17 8l4 4m0 0l-4 4m4-4H3" strokeWidth="3"/></svg>
              </div>
            </button>

            {/* Authority Portal */}
            <button 
              onClick={() => selectPortal('authority')}
              className="group relative bg-[#0f172a] border border-white/5 p-12 rounded-[4rem] text-left hover:bg-[#1a1408] hover:border-amber-500/30 transition-all duration-500 hover:-translate-y-4 shadow-3xl"
            >
              <div className="w-20 h-20 bg-amber-500/10 rounded-3xl flex items-center justify-center text-amber-400 mb-10 group-hover:scale-110 transition-transform border border-amber-500/20">
                <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeWidth="2"/></svg>
              </div>
              <h3 className="text-4xl font-black text-white mb-4 tracking-tight">Authority</h3>
              <p className="text-slate-400 text-lg leading-relaxed mb-10 opacity-60">Operational control for agency units. Deploy field teams and intimate resolutions.</p>
              <div className="text-amber-500 text-xs font-black uppercase tracking-[0.3em] flex items-center gap-3 group-hover:gap-5 transition-all">
                FIELD PROTOCOLS <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17 8l4 4m0 0l-4 4m4-4H3" strokeWidth="3"/></svg>
              </div>
            </button>

            {/* Admin Portal */}
            <button 
              onClick={() => selectPortal('admin')}
              className="group relative bg-[#0f172a] border border-white/5 p-12 rounded-[4rem] text-left hover:bg-[#131d36] hover:border-indigo-500/30 transition-all duration-500 hover:-translate-y-4 shadow-3xl"
            >
              <div className="w-20 h-20 bg-indigo-500/10 rounded-3xl flex items-center justify-center text-indigo-400 mb-10 group-hover:scale-110 transition-transform border border-indigo-500/20">
                <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 21l-8-4.5v-9L12 3l8 4.5v9l-8 4.5z" strokeWidth="2"/></svg>
              </div>
              <h3 className="text-4xl font-black text-white mb-4 tracking-tight">Admin</h3>
              <p className="text-slate-400 text-lg leading-relaxed mb-10 opacity-60">High-level dispatch and final verification. Monitor regional metrics and unit efficacy.</p>
              <div className="text-indigo-500 text-xs font-black uppercase tracking-[0.3em] flex items-center gap-3 group-hover:gap-5 transition-all">
                COMMAND AUTHORIZATION <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17 8l4 4m0 0l-4 4m4-4H3" strokeWidth="3"/></svg>
              </div>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-all duration-1000 ${theme.bg} flex flex-col items-center justify-center p-6 relative overflow-hidden`}>
      <div className="absolute inset-0 bg-[#020617]/50 pointer-events-none" />
      
      <div className="relative z-10 w-full max-w-xl bg-white rounded-[4rem] p-16 shadow-[0_50px_100px_rgba(0,0,0,0.5)] animate-slide-up">
        <button onClick={() => setView('selector')} className="absolute top-10 left-10 text-slate-400 hover:text-slate-900 transition-colors flex items-center gap-2 text-[10px] font-black uppercase tracking-widest">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M10 19l-7-7m0 0l7-7m-7 7h18" strokeWidth="3"/></svg>
          Return to Selection
        </button>

        <div className="text-center mb-12 mt-4">
          <p className={`text-[10px] font-black uppercase tracking-[0.4em] ${theme.text} mb-4`}>{theme.label} Node Authorization</p>
          <h2 className="text-5xl font-black text-slate-900 tracking-tighter">
            {view === 'login' ? 'Access Key' : 'Join Network'}
          </h2>
        </div>

        <form onSubmit={handleAuth} className="space-y-6">
          {view === 'register' && (
            <div className="space-y-6">
              <input type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="Full Legal Name" 
                className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-3xl font-bold focus:ring-4 outline-none transition-all" />
              {role === 'authority' && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-4">Agency Designation</label>
                  <select value={org} onChange={(e) => setOrg(e.target.value)} className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-3xl font-bold focus:ring-4 outline-none transition-all appearance-none">
                    {AUTHORITIES.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
              )}
            </div>
          )}

          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Official Email Token" 
            className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-3xl font-bold focus:ring-4 outline-none transition-all" />

          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Encrypted Password" 
            className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-3xl font-bold focus:ring-4 outline-none transition-all" />

          {error && <div className="bg-red-50 text-red-600 text-[10px] font-black p-6 rounded-3xl border border-red-100">{error}</div>}

          <button disabled={loading} type="submit" className={`w-full py-6 rounded-[2rem] font-black text-white shadow-2xl transition-all active:scale-95 disabled:opacity-50 text-xl ${theme.btn}`}>
            {loading ? 'Initializing...' : view === 'login' ? 'Establish Secure Link' : 'Register New Node'}
          </button>
        </form>

        <div className="mt-12 pt-10 border-t border-slate-50 text-center space-y-6">
          <p className="text-slate-400 font-bold text-sm">
            {view === 'login' ? "Node not registered?" : "Already recognized by the grid?"}
            <button onClick={() => setView(view === 'login' ? 'register' : 'login')} className={`ml-2 font-black ${theme.text} hover:underline`}>
              {view === 'login' ? 'Apply Now' : 'Access Node'}
            </button>
          </p>
          <div className="p-6 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Operational Sandbox Access</p>
             <button onClick={() => {
                 if (role === 'admin') { setEmail('admin@ecoguard.org'); setPassword('admin'); }
                 else if (role === 'authority') { setEmail('forestry@agency.gov'); setPassword('forest'); }
                 else { setEmail('user@test.com'); setPassword('user'); }
               }} className="text-[11px] font-black text-slate-800 hover:text-emerald-600 underline transition-all">
               Auto-Inject {role} Credentials
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
