
import React, { useState, useRef, useEffect } from 'react';
import { analyzeEnvironmentalImage } from '../services/geminiService.ts';
import { AIAnalysisResult, IncidentType, Severity, Report } from '../types.ts';

interface ReportWizardProps {
  onComplete: (report: Partial<Report>) => void;
}

const ReportWizard: React.FC<ReportWizardProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [description, setDescription] = useState('');
  const [manualAddress, setManualAddress] = useState('');
  const [location, setLocation] = useState<{lat: number, lng: number, address: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const initialAddr = "Locking GPS coordinates...";
        setLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          address: initialAddr
        });
        setManualAddress(initialAddr);
        
        // Simulated reverse geocoding
        setTimeout(() => {
          const detected = `District ${Math.floor(Math.random()*100)}, Nature Corridor B`;
          setLocation(prev => prev ? ({...prev, address: detected}) : null);
          setManualAddress(detected);
        }, 1500);
      }, (err) => {
        setManualAddress("Manual input required - GPS unavailable");
      });
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setStep(2);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStartAnalysis = async () => {
    if (!image) return;
    setAnalyzing(true);
    try {
      const base64Data = image.split(',')[1];
      const result = await analyzeEnvironmentalImage(base64Data);
      setAnalysis(result);
      setStep(3);
    } catch (err) {
      alert("AI analysis failed. Please enter details manually.");
      setStep(3);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSubmit = () => {
    onComplete({
      type: analysis?.detectedType || IncidentType.OTHER,
      severity: analysis?.severity || Severity.MEDIUM,
      description: description || analysis?.explanation || '',
      imageUrl: image || undefined,
      aiInsights: analysis?.explanation,
      location: { 
        lat: location?.lat || 0, 
        lng: location?.lng || 0, 
        address: manualAddress || location?.address || "Manual Site Input" 
      },
      timestamp: new Date(),
    });
  };

  return (
    <div className="bg-white rounded-[4rem] p-12 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] max-w-xl mx-auto border border-slate-100 animate-slide-up">
      <div className="flex items-center gap-4 mb-12">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
            <div className={`h-full transition-all duration-700 ${step >= s ? 'bg-emerald-500' : 'bg-transparent'}`} />
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="text-center py-10">
          <div className="w-24 h-24 bg-emerald-50 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 text-emerald-600 shadow-inner">
            <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" strokeWidth="2"/><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" strokeWidth="2"/></svg>
          </div>
          <h2 className="text-4xl font-black mb-4 tracking-tighter">Site Evidence</h2>
          <p className="text-slate-500 mb-12 font-medium">Capture or upload high-resolution media to initialize the environmental audit report.</p>
          <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />
          <button onClick={() => fileInputRef.current?.click()} className="w-full bg-slate-900 text-white font-black py-6 rounded-3xl shadow-2xl hover:bg-black transition-all active:scale-[0.98]">Select Evidence Artifact</button>
        </div>
      )}

      {step === 2 && image && (
        <div className="text-center">
          <div className="relative group mb-10">
            <img src={image} className="w-full aspect-square object-cover rounded-[3rem] shadow-2xl" alt="Evidence" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-[3rem] flex items-center justify-center">
              <button onClick={() => setImage(null)} className="p-5 bg-white/20 backdrop-blur-md rounded-full text-white">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2.5"/></svg>
              </button>
            </div>
          </div>
          <h2 className="text-3xl font-black mb-3 tracking-tighter text-slate-900">EcoGuard Vision</h2>
          <p className="text-slate-500 mb-10 font-medium">Execute deep neural scan to automatically classify and assess severity levels.</p>
          <div className="flex gap-4">
            <button disabled={analyzing} onClick={handleStartAnalysis} className="flex-1 bg-indigo-600 text-white font-black py-5 rounded-3xl shadow-xl hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center justify-center gap-4 active:scale-[0.98]">
              {analyzing ? (
                <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeWidth="2.5"/></svg>
              )}
              {analyzing ? "Synthesizing Data..." : "Run Neural Audit"}
            </button>
            <button disabled={analyzing} onClick={() => setStep(3)} className="px-10 border border-slate-200 font-black py-5 rounded-3xl text-slate-400 hover:bg-slate-50 transition-all">Manual Entry</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          {/* Manual Address Input Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between pl-2">
               <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.2em] flex items-center gap-2">
                  <svg className="w-4 h-4 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" strokeWidth="2.5"/></svg>
                  Physical Coordinates
               </h4>
               <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100 uppercase tracking-widest">Active GPS Grid</span>
            </div>
            <div className="relative group">
              <input 
                type="text" 
                value={manualAddress} 
                onChange={(e) => setManualAddress(e.target.value)}
                placeholder="Specific landmark or sector address..."
                className="w-full bg-slate-50 border-2 border-slate-100 rounded-3xl px-8 py-5 font-bold text-slate-900 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-500/40 outline-none transition-all group-hover:border-slate-200"
              />
              <div className="absolute right-6 top-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-xl shadow-sm flex items-center justify-center">
                 <svg className="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth="2.5"/></svg>
              </div>
            </div>
          </div>

          {/* AI Synthesis Summary */}
          <div className="grid grid-cols-2 gap-4">
             <div className="p-6 bg-slate-50/50 rounded-3xl border border-slate-100 flex flex-col justify-center">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Anomaly Class</p>
                <p className="text-sm font-black text-slate-900">{analysis?.detectedType || 'Pending'}</p>
             </div>
             <div className="p-6 bg-slate-50/50 rounded-3xl border border-slate-100 flex flex-col justify-center">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Severity Vector</p>
                <p className={`text-sm font-black ${analysis?.severity === Severity.CRITICAL ? 'text-red-600' : 'text-orange-500'}`}>{analysis?.severity || 'Standard'}</p>
             </div>
          </div>

          {/* Observations / Description */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.2em] pl-2">Audit Narrative</h4>
            <div className="bg-white border-2 border-slate-900 rounded-[2.5rem] p-1 shadow-[4px_4px_0px_#0f172a] focus-within:shadow-[6px_6px_0px_#10b981] transition-all">
               <textarea 
                  value={description} 
                  onChange={(e) => setDescription(e.target.value)} 
                  placeholder="Record specific field details for the response unit..." 
                  className="w-full bg-transparent p-6 font-bold text-slate-900 placeholder:text-slate-300 outline-none min-h-[160px] resize-none" 
               />
            </div>
          </div>

          {/* Final Submission Button */}
          <button 
            onClick={handleSubmit} 
            className="w-full bg-[#059669] text-white font-black py-6 rounded-full shadow-[0_20px_40px_-12px_rgba(5,150,105,0.4)] hover:bg-[#047857] hover:translate-y-[-2px] active:scale-[0.97] transition-all text-lg tracking-tight"
          >
            Authorize Secure Dispatch
          </button>
        </div>
      )}
    </div>
  );
};

export default ReportWizard;
