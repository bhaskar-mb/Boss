
import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { generateCommunityUpdate } from '../services/geminiService.ts';
import { Report, User } from '../types.ts';

const data = [
  { name: 'Mon', incidents: 12 },
  { name: 'Tue', incidents: 19 },
  { name: 'Wed', incidents: 14 },
  { name: 'Thu', incidents: 32 },
  { name: 'Fri', incidents: 22 },
  { name: 'Sat', incidents: 45 },
  { name: 'Sun', incidents: 28 },
];

interface DashboardProps {
  reports: Report[];
  user: User;
  onNewReport: () => void;
  onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ reports, user, onNewReport, onNavigate }) => {
  const [aiSummary, setAiSummary] = useState("EcoGuard is cross-referencing recent environmental data streams...");

  useEffect(() => {
    const fetchSummary = async () => {
      if (reports.length > 0) {
        try {
          const summary = await generateCommunityUpdate(reports.slice(0, 5));
          setAiSummary(summary);
        } catch (e) {
          setAiSummary("The EcoGuard network remains fully operational. Your reports provide critical data points for environmental protection.");
        }
      }
    };
    fetchSummary();
  }, [reports]);

  const isAdmin = user.role === 'admin';
  const isAuth = user.role === 'authority';

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
      
      {/* Dynamic Hero Section based on Role */}
      <div className={`relative overflow-hidden rounded-[4rem] p-12 md:p-20 text-white shadow-3xl ${
        isAdmin ? 'bg-gradient-to-br from-indigo-950 to-slate-900 shadow-indigo-900/20' :
        isAuth ? 'bg-gradient-to-br from-amber-950 to-slate-900 shadow-amber-900/20' :
        'bg-gradient-to-br from-slate-950 to-[#061e1a] shadow-emerald-900/20'
      }`}>
        <div className={`absolute top-0 right-0 w-[500px] h-[500px] rounded-full blur-[120px] animate-pulse ${
          isAdmin ? 'bg-indigo-500/10' : isAuth ? 'bg-amber-500/10' : 'bg-emerald-500/5'
        }`} />

        <div className="relative z-10 flex flex-col xl:flex-row xl:items-center justify-between gap-16">
          <div className="max-w-3xl">
            <div className={`inline-flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-[0.3em] mb-10 ${
              isAdmin ? 'text-indigo-400' : isAuth ? 'text-amber-400' : 'text-emerald-400'
            }`}>
               <span className={`w-2.5 h-2.5 rounded-full animate-ping ${
                 isAdmin ? 'bg-indigo-400' : isAuth ? 'bg-amber-400' : 'bg-emerald-400'
               }`} />
               Node Status: {isAdmin ? 'Admin Command' : isAuth ? 'Authority Terminal' : 'User Interface'}
            </div>
            
            <h1 className="text-6xl md:text-8xl font-black mb-8 leading-[1.02] tracking-tighter">
              {isAdmin ? 'Global Oversight.' : isAuth ? 'Strategic Action.' : 'Safeguard Nature.'}
            </h1>

            <p className="text-xl text-white/60 font-medium mb-12 max-w-xl leading-relaxed">
              {isAdmin ? 'System-wide monitoring of environmental anomalies and agency response protocols.' : 
               isAuth ? 'Direct operational interface for executing habitat restoration and wildlife protection tasks.' : 
               'Contribute high-fidelity data to the EcoGuard grid to ensure a sustainable future for all.'}
            </p>
            
            <div className="flex flex-wrap gap-5">
              {!isAdmin && !isAuth ? (
                <>
                  <button 
                    onClick={onNewReport}
                    className="bg-emerald-600 text-white px-12 py-6 rounded-3xl font-black hover:bg-emerald-500 transition-all flex items-center gap-4 shadow-2xl shadow-emerald-900/40 active:scale-95 text-xl"
                  >
                    <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 4v16m8-8H4" strokeWidth="4" strokeLinecap="round"/></svg>
                    Initialize Report
                  </button>
                  <button 
                    onClick={() => onNavigate('notes')}
                    className="bg-white/5 border border-white/10 text-white px-10 py-6 rounded-3xl font-black hover:bg-white/10 transition-all flex items-center gap-4 text-xl"
                  >
                    <span className="text-red-500 text-2xl animate-pulse">🚨</span>
                    Crisis Hotlines
                  </button>
                </>
              ) : (
                <button 
                  onClick={() => onNavigate('reports')}
                  className={`px-12 py-6 rounded-3xl font-black transition-all flex items-center gap-4 shadow-2xl active:scale-95 text-xl ${
                    isAdmin ? 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-900/40' : 'bg-amber-600 hover:bg-amber-500 shadow-amber-900/40'
                  }`}
                >
                  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" strokeWidth="3"/></svg>
                  {isAdmin ? 'Audit Dispatch' : 'Operational Tasks'}
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-6 xl:w-96">
             <div className="bg-white/5 backdrop-blur-2xl border border-white/10 p-10 rounded-[3rem] shadow-2xl">
                <p className={`${isAdmin ? 'text-indigo-400' : isAuth ? 'text-amber-400' : 'text-emerald-400'} text-xs font-black uppercase tracking-widest mb-3`}>
                  {isAdmin ? 'System Load' : isAuth ? 'Unit Impact' : 'User Contribution'}
                </p>
                <div className="flex items-baseline gap-2">
                   <p className="text-6xl font-black tracking-tighter text-white">
                      {isAdmin ? reports.length : isAuth ? reports.filter(r => r.assignedAuthorityId === user.organization).length : user.points}
                   </p>
                   <span className="text-sm font-black text-white/40 uppercase tracking-widest">
                      {isAdmin ? 'Objects' : isAuth ? 'Deployments' : 'Credits'}
                   </span>
                </div>
             </div>
             
             <div className="bg-white/5 backdrop-blur-2xl border border-white/10 p-10 rounded-[3rem] shadow-2xl">
                <p className="text-blue-400 text-xs font-black uppercase tracking-widest mb-4">Network Coverage</p>
                <div className="flex items-center gap-4">
                   <div className="flex-1 h-3 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 w-[89%] rounded-full shadow-[0_0_15px_rgba(59,130,246,0.5)]" />
                   </div>
                   <span className="text-lg font-black text-white">89%</span>
                </div>
                <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest mt-4">Active Sensor Grid Optimization</p>
             </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-12">
        {/* Statistics Chart */}
        <div className="lg:col-span-2 bg-white rounded-[4rem] p-12 border border-slate-100 shadow-2xl">
          <div className="flex items-center justify-between mb-12">
            <div>
               <h3 className="font-black text-3xl text-slate-900 tracking-tight">Ecosystem Dynamics</h3>
               <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-2">Real-time Environmental Pulse Index</p>
            </div>
            <div className="flex gap-2">
               {['Live', '24H', '7D'].map(t => (
                 <button key={t} className={`px-4 py-2 rounded-xl text-[10px] font-black tracking-widest ${t === 'Live' ? 'bg-slate-900 text-white' : 'text-slate-400'}`}>{t}</button>
               ))}
            </div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorInc" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 900}} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.1)' }}
                  itemStyle={{ fontWeight: 900, color: '#0f172a', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="incidents" stroke="#10b981" strokeWidth={5} fill="url(#colorInc)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Intelligence Box */}
        <div className="bg-slate-900 rounded-[4rem] p-12 text-white flex flex-col justify-between shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.5)]" />
          <div className="space-y-10 relative z-10">
            <div className="flex items-center gap-5">
               <div className="w-16 h-16 bg-white/5 rounded-3xl flex items-center justify-center text-emerald-400 border border-white/10 group-hover:scale-110 transition-transform">
                 <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M13 10V3L4 14h7v7l9-11h-7z" strokeWidth="2.5"/></svg>
               </div>
               <div>
                 <h3 className="font-black text-xl tracking-tight">EcoGuard Intelligence</h3>
                 <p className="text-[10px] font-black uppercase text-emerald-400 tracking-widest">Sentinel Core Synthesis Feed</p>
               </div>
            </div>
            <p className="text-white/60 font-bold italic leading-relaxed text-lg">"{aiSummary}"</p>
            
            {/* Quick Emergency Links for Authority Help */}
            <div className="pt-4 space-y-3">
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1">Crisis Response Units</p>
               <div className="grid grid-cols-2 gap-3">
                  <a href="tel:1800FIRE" className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs font-bold text-red-400 hover:bg-red-500/20 transition-all flex items-center gap-2">
                     <span className="text-lg">🔥</span> Fire Unit
                  </a>
                  <a href="tel:1800WILD" className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs font-bold text-amber-400 hover:bg-amber-500/20 transition-all flex items-center gap-2">
                     <span className="text-lg">🐾</span> Wildlife
                  </a>
               </div>
            </div>
          </div>
          <button 
            onClick={() => onNavigate('notes')} 
            className="w-full mt-8 py-6 bg-emerald-600 rounded-[2rem] text-white font-black text-sm hover:bg-emerald-500 transition-all shadow-3xl shadow-emerald-900/60 flex items-center justify-center gap-3 active:scale-[0.98]"
          >
            Access Guardian Library
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M14 5l7 7m0 0l-7 7m7-7H3" strokeWidth="3"/></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
