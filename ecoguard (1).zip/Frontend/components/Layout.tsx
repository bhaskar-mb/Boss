
import React, { useState } from 'react';

interface LayoutProps {
  children: React.ReactNode;
  user: any;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const EMERGENCY_CONTACTS = [
  { agency: 'Wildlife Rescue', phone: '1-800-RESCUE-W', icon: '🐾', desc: 'Injured animals & poaching' },
  { agency: 'Forestry Fire', phone: '911-FOREST', icon: '🔥', desc: 'Wildfires & logging' },
  { agency: 'EPA Rapid Response', phone: '0800-ECO-HELP', icon: '🛢️', desc: 'Spills & pollution' },
  { agency: 'Marine Rescue', phone: '999-OCEAN-SOS', icon: '🐋', desc: 'Coastal & ocean distress' },
  { agency: 'Eco-Toxic Control', phone: '1-800-TOXIC-OFF', icon: '☣️', desc: 'Hazardous waste dumping' },
  { agency: 'National Park Police', phone: '1-800-RANGER-911', icon: '🚓', desc: 'Criminal activity in parks' },
];

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, activeTab, setActiveTab }) => {
  const [showSOS, setShowSOS] = useState(false);
  const isAdmin = user.role === 'admin';
  const isAuth = user.role === 'authority';

  return (
    <div className={`min-h-screen flex flex-col ${isAdmin ? 'bg-[#0f172a]/5' : isAuth ? 'bg-amber-50/20' : 'bg-slate-50'}`}>
      <header className="glass sticky top-0 z-50 border-b border-slate-200/60 px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-4 cursor-pointer group" onClick={() => setActiveTab('dashboard')}>
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-xl transition-transform group-hover:rotate-6 ${
            isAdmin ? 'bg-indigo-600' : isAuth ? 'bg-amber-600' : 'bg-emerald-600'
          }`}>
             <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 21l-8-4.5v-9L12 3l8 4.5v9l-8 4.5z" strokeWidth="2.5"/></svg>
          </div>
          <div>
            <span className="font-black text-2xl text-slate-900 tracking-tight">EcoGuard</span>
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.3em]">{isAuth ? user.organization : 'Global Protection Grid'}</p>
          </div>
        </div>

        <nav className="hidden lg:flex items-center gap-1.5 p-1.5 bg-slate-100/50 rounded-2xl border border-slate-200/50">
          {[
            { id: 'dashboard', label: 'Command' },
            { id: 'reports', label: 'Operations' },
            { id: 'notes', label: 'Library' },
            { id: 'leaderboard', label: 'Audit' }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-100 hover:text-slate-600'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowSOS(true)}
            className="hidden sm:flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-100 transition-all border border-red-100"
          >
            <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
            SOS Contacts
          </button>
          <div className="text-right hidden sm:block">
            <p className="text-sm font-black text-slate-900">{user.name}</p>
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Authorized Personnel</p>
          </div>
          <img src={user.avatar} className="w-10 h-10 rounded-xl border-2 border-slate-200" alt="Avatar" />
          <button onClick={onLogout} className="p-3 bg-slate-100 rounded-xl text-slate-400 hover:text-red-500 transition-all border border-slate-200">
             <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17 16l4-4m0 0l-4-4m4 4H7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-8 pb-32">
        {children}
      </main>

      {/* Floating Emergency SOS Button for Mobile */}
      <button 
        onClick={() => setShowSOS(true)}
        className="fixed bottom-24 right-8 lg:bottom-12 z-40 w-14 h-14 bg-red-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all animate-bounce"
      >
        <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" strokeWidth="2.5"/></svg>
      </button>

      {/* Emergency SOS Modal - High Fidelity Redesign */}
      {showSOS && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-[#f8faff] rounded-[4rem] w-full max-w-xl p-12 shadow-[0_50px_100px_rgba(0,0,0,0.5)] animate-in zoom-in-95 duration-300 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-start justify-between mb-12">
              <div>
                <h2 className="text-5xl font-black text-[#0f172a] tracking-tight leading-none mb-3">Emergency Grid</h2>
                <p className="text-[11px] font-black text-red-500 uppercase tracking-[0.3em] mt-1">High-Priority Authority Links</p>
              </div>
              <button onClick={() => setShowSOS(false)} className="w-14 h-14 rounded-2xl bg-white shadow-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all border border-slate-100">
                <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M6 18L18 6M6 6l12 12" strokeWidth="3"/></svg>
              </button>
            </div>

            <div className="space-y-6">
              {EMERGENCY_CONTACTS.map((contact, idx) => (
                <div key={idx} className="group flex items-center justify-between p-8 bg-white rounded-[2.5rem] border border-slate-100 hover:shadow-2xl transition-all duration-300">
                  <div className="flex items-center gap-8">
                    <span className="text-4xl filter grayscale group-hover:grayscale-0 transition-all duration-300">{contact.icon}</span>
                    <div>
                      <h4 className="font-black text-xl text-[#0f172a] mb-1">{contact.agency}</h4>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{contact.desc}</p>
                    </div>
                  </div>
                  <a href={`tel:${contact.phone.replace(/[^0-9]/g, '')}`} className="px-8 py-5 bg-[#0f172a] text-white rounded-[1.5rem] text-[13px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/20 active:scale-95 whitespace-nowrap">
                    {contact.phone}
                  </a>
                </div>
              ))}
            </div>

            <div className="mt-14 pt-8 border-t border-slate-200 text-center">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-relaxed max-w-xs mx-auto">
                 Verified Authority Database. <br/> Misuse of emergency channels is subject to audit.
               </p>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Nav */}
      <nav className="fixed bottom-0 left-0 right-0 glass border-t border-slate-200 lg:hidden flex justify-around py-5">
         <button onClick={() => setActiveTab('dashboard')} className={activeTab === 'dashboard' ? 'text-emerald-600' : 'text-slate-400'}>
            <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" strokeWidth="2.5"/></svg>
         </button>
         <button onClick={() => setActiveTab('reports')} className={activeTab === 'reports' ? 'text-emerald-600' : 'text-slate-400'}>
            <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2.5"/></svg>
         </button>
      </nav>
    </div>
  );
};

export default Layout;
