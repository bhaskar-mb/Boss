
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult, IncidentType, Severity } from "../types";

// Always use process.env.API_KEY directly and initialize as a named parameter.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeEnvironmentalImage = async (base64Image: string): Promise<AIAnalysisResult> => {
  const model = 'gemini-3-flash-preview';
  
  // Update contents to use the recommended { parts: [...] } structure for multiple parts.
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: `Analyze this image for environmental or wildlife concerns. 
          Identify if it shows land damage, illegal tree cutting, injured animals, or road accidents. 
          Assess the severity and provide a short explanation and recommended immediate action.`,
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          detectedType: {
            type: Type.STRING,
            description: "Category of the incident: Land Damage, Illegal Logging, Injured Wildlife, Animal Road Accident, Pollution, or Other",
          },
          severity: {
            type: Type.STRING,
            description: "Severity level: Low, Medium, High, or Critical",
          },
          explanation: {
            type: Type.STRING,
            description: "Concise description of what the AI sees",
          },
          recommendedAction: {
            type: Type.STRING,
            description: "A professional recommendation for the user or authorities",
          },
        },
        required: ["detectedType", "severity", "explanation", "recommendedAction"],
      },
    },
  });

  // response.text is a property, not a method.
  const text = response.text;
  if (!text) {
    throw new Error("Could not interpret AI analysis (empty response).");
  }
  try {
    return JSON.parse(text) as AIAnalysisResult;
  } catch (error) {
    console.error("Failed to parse AI response", text);
    throw new Error("Could not interpret AI analysis.");
  }
};

export const generateCommunityUpdate = async (recentReports: any[]) => {
  const model = 'gemini-3-flash-preview';
  const prompt = `Based on these recent environmental reports in the area: ${JSON.stringify(recentReports)}, 
  write a short, inspiring 2-sentence summary for a community dashboard that encourages students and the public to stay involved.`;
  
  // contents can be a simple string for text-only prompts.
  const response = await ai.models.generateContent({
    model,
    contents: prompt
  });
  
  // Fallback string in case response.text is undefined.
  return response.text || "Every report you make helps us protect our shared natural environment.";
};
